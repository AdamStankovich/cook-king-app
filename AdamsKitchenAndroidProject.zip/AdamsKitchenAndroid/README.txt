Adam's Kitchen Android wrapper

Open this folder in Android Studio and build an APK:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The app is fully local and loads app/src/main/assets/index.html in a WebView.
Save data uses the WebView's local storage on the phone.
