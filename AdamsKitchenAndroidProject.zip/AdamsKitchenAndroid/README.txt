CookKing v3.0

Simplified redesign:
- 4 tabs: Home, Log, Meals, Progress
- Clickable full-screen meal gallery photos
- Cleaner meal details
- Only 3 visible goals at a time
- 5 broad skill groups instead of dense skill trees
- Rare, meaningful milestones instead of achievement clutter
- One clean result card after saving a cook
- Same applicationId, localStorage key, and stable signing key as v2.6

Build: ./gradlew assembleDebug
