Cook King Android wrapper — v2.2

Important update behavior:
- This build uses a stable bundled signing key so future APKs built from this project can update in place.
- Because older GitHub Actions builds used a randomly generated debug key, Android cannot update those older installs.
- Install v2.2 once after uninstalling the older build. From v2.2 onward, future builds using this project should install over the existing app without deleting its data.
- The bundled key is for this personal sideloaded app only. Do not use it for a Play Store production release.
