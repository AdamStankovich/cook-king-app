plugins { id("com.android.application") }

android {
    namespace = "com.adamskitchen.rpg"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.adamskitchen.rpg"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
