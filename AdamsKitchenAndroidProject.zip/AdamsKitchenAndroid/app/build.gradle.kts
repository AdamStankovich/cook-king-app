plugins { id("com.android.application") }

android {
    namespace = "com.adamskitchen.rpg"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.adamskitchen.rpg"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
