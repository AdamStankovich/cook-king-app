plugins { id("com.android.application") }

android {
    namespace = "com.adamskitchen.rpg"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.adamskitchen.rpg"
        minSdk = 24
        targetSdk = 34
        versionCode = 6
        versionName = "2.4"
    }

    signingConfigs {
        create("cookKingStable") {
            storeFile = file("cookking-update-key.jks")
            storePassword = "cookking-local-2026"
            keyAlias = "cookking"
            keyPassword = "cookking-local-2026"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("cookKingStable")
        }
    }
}
